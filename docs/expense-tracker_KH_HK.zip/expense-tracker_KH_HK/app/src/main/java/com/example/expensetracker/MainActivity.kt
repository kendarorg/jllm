package com.example.expensetracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.expensetracker.data.Expense
import com.example.expensetracker.data.ExpenseType
import com.example.expensetracker.data.ExpenseWithTypes
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ExpenseApp()
                }
            }
        }
    }
}

private enum class Screen { Expenses, Types }

@Composable
fun ExpenseApp(vm: ExpenseViewModel = viewModel()) {
    var screen by remember { mutableStateOf(Screen.Expenses) }

    BackHandler(enabled = screen != Screen.Expenses) { screen = Screen.Expenses }

    when (screen) {
        Screen.Expenses -> ExpenseScreen(vm = vm, onManageTypes = { screen = Screen.Types })
        Screen.Types -> TypesScreen(vm = vm, onBack = { screen = Screen.Expenses })
    }
}

// ---------------- Expenses ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpenseScreen(vm: ExpenseViewModel, onManageTypes: () -> Unit) {
    val expenses by vm.expenses.collectAsState()
    val types by vm.types.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    val total = expenses.sumOf { it.expense.amountCents }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Expenses") },
                actions = { TextButton(onClick = onManageTypes) { Text("Types") } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add expense")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "Total: ${ExpenseViewModel.formatCents(total)}",
                style = MaterialTheme.typography.headlineSmall
            )
            Spacer(Modifier.height(12.dp))

            if (expenses.isEmpty()) {
                Text("No expenses yet. Tap + to add one.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(expenses, key = { it.expense.id }) { item ->
                        ExpenseRow(item = item, onDelete = { vm.deleteExpense(item.expense) })
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddExpenseDialog(
            types = types,
            onDismiss = { showAdd = false },
            onSave = { amount, note, typeIds ->
                val error = vm.addExpense(amount, note, typeIds)
                if (error == null) showAdd = false
                error
            }
        )
    }
}

@Composable
fun ExpenseRow(item: ExpenseWithTypes, onDelete: () -> Unit) {
    val expense = item.expense
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.types.joinToString(", ") { it.name }.ifEmpty { "No type" },
                    style = MaterialTheme.typography.titleMedium
                )
                if (expense.note.isNotBlank()) {
                    Text(expense.note, style = MaterialTheme.typography.bodySmall)
                }
                Text(
                    DATE_FORMAT.format(Date(expense.dateMillis)),
                    style = MaterialTheme.typography.labelSmall
                )
            }
            Text(
                ExpenseViewModel.formatCents(expense.amountCents),
                style = MaterialTheme.typography.titleMedium
            )
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete expense")
            }
        }
    }
}

/** onSave returns an error message, or null when the expense was saved (dialog then closes). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddExpenseDialog(
    types: List<ExpenseType>,
    onDismiss: () -> Unit,
    onSave: (amount: String, note: String, typeIds: Set<Long>) -> String?
) {
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(emptySet<Long>()) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New expense") },
        text = {
            Column {
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Amount (e.g. 12.50)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Note (optional)") },
                    singleLine = true
                )
                Spacer(Modifier.height(12.dp))
                Text("Types", style = MaterialTheme.typography.labelLarge)
                if (types.isEmpty()) {
                    Text(
                        "No types yet. Close this and create some via \"Types\" first.",
                        style = MaterialTheme.typography.bodySmall
                    )
                } else {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        types.forEach { type ->
                            val isSelected = type.id in selected
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selected = if (isSelected) selected - type.id else selected + type.id
                                },
                                label = { Text(type.name) }
                            )
                        }
                    }
                }
                error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { error = onSave(amount, note, selected) }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ---------------- Types management ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TypesScreen(vm: ExpenseViewModel, onBack: () -> Unit) {
    val types by vm.types.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ExpenseType?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Expense types") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showNew = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add type")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            if (types.isEmpty()) {
                Text("No types yet. Tap + to add one.")
            } else {
                Text(
                    "Tap a type to rename it. Deleting a type removes it from existing expenses.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(types, key = { it.id }) { type ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = type.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { editing = type }
                                )
                                IconButton(onClick = { vm.deleteType(type) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete type")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        TypeEditDialog(
            title = "New type",
            initialName = "",
            onDismiss = { showNew = false },
            onSave = { name ->
                val error = vm.createType(name)
                if (error == null) showNew = false
                error
            }
        )
    }

    editing?.let { type ->
        TypeEditDialog(
            title = "Rename type",
            initialName = type.name,
            onDismiss = { editing = null },
            onSave = { name ->
                val error = vm.renameType(type, name)
                if (error == null) editing = null
                error
            }
        )
    }
}

@Composable
fun TypeEditDialog(
    title: String,
    initialName: String,
    onDismiss: () -> Unit,
    onSave: (String) -> String?
) {
    var name by remember { mutableStateOf(initialName) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Type name (e.g. Food)") },
                    singleLine = true
                )
                error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { error = onSave(name) }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

private val DATE_FORMAT = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
