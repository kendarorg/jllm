package com.example.expensetracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** A single expense. Amount is stored in cents to avoid floating-point errors. Types are linked via [ExpenseTypeCrossRef]. */
@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amountCents: Long,
    val note: String,
    val dateMillis: Long = System.currentTimeMillis()
)
