package com.example.expensetracker.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseTypeDao {

    @Query("SELECT * FROM expense_types ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<ExpenseType>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(type: ExpenseType): Long

    @Update(onConflict = OnConflictStrategy.IGNORE)
    suspend fun update(type: ExpenseType): Int

    @Query("DELETE FROM expense_type_cross_ref WHERE typeId = :typeId")
    suspend fun deleteTagLinksForType(typeId: Long)

    @Delete
    suspend fun delete(type: ExpenseType)
}
