package com.example.expensetracker.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** A user-defined type/tag for expenses, e.g. "Food", "Travel". Names are unique. */
@Entity(
    tableName = "expense_types",
    indices = [Index(value = ["name"], unique = true)]
)
data class ExpenseType(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)
