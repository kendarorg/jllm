package com.example.expensetracker.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {

    @Transaction
    @Query("SELECT * FROM expenses ORDER BY dateMillis DESC, id DESC")
    fun observeAllWithTypes(): Flow<List<ExpenseWithTypes>>

    @Insert
    suspend fun insertExpense(expense: Expense): Long

    @Insert
    suspend fun insertTagLinks(links: List<ExpenseTypeCrossRef>)

    @Query("DELETE FROM expense_type_cross_ref WHERE expenseId = :expenseId")
    suspend fun deleteTagLinks(expenseId: Long)

    @Delete
    suspend fun delete(expense: Expense)
}
