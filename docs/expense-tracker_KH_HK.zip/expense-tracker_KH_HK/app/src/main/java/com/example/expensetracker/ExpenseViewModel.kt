package com.example.expensetracker

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.example.expensetracker.data.AppDatabase
import com.example.expensetracker.data.Expense
import com.example.expensetracker.data.ExpenseType
import com.example.expensetracker.data.ExpenseTypeCrossRef
import com.example.expensetracker.data.ExpenseWithTypes
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.math.RoundingMode

/** All methods that can fail return an error message, or null on success. */
class ExpenseViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.get(application)
    private val expenseDao = db.expenseDao()
    private val typeDao = db.expenseTypeDao()

    val expenses: StateFlow<List<ExpenseWithTypes>> = expenseDao.observeAllWithTypes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val types: StateFlow<List<ExpenseType>> = typeDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    // ---- Expenses ----

    fun addExpense(amountText: String, note: String, typeIds: Set<Long>): String? {
        val cents = parseToCents(amountText)
        if (cents == null || cents <= 0) return "Enter an amount greater than 0"
        if (typeIds.isEmpty()) return "Select at least one type"
        viewModelScope.launch {
            db.withTransaction {
                val expenseId = expenseDao.insertExpense(Expense(amountCents = cents, note = note.trim()))
                expenseDao.insertTagLinks(typeIds.map { ExpenseTypeCrossRef(expenseId = expenseId, typeId = it) })
            }
        }
        return null
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            db.withTransaction {
                expenseDao.deleteTagLinks(expense.id)
                expenseDao.delete(expense)
            }
        }
    }

    // ---- Types ----

    fun createType(rawName: String): String? {
        val name = rawName.trim()
        validateTypeName(name, excludeId = null)?.let { return it }
        viewModelScope.launch { typeDao.insert(ExpenseType(name = name)) }
        return null
    }

    fun renameType(type: ExpenseType, rawName: String): String? {
        val name = rawName.trim()
        validateTypeName(name, excludeId = type.id)?.let { return it }
        viewModelScope.launch { typeDao.update(type.copy(name = name)) }
        return null
    }

    fun deleteType(type: ExpenseType) {
        viewModelScope.launch {
            db.withTransaction {
                typeDao.deleteTagLinksForType(type.id)
                typeDao.delete(type)
            }
        }
    }

    private fun validateTypeName(name: String, excludeId: Long?): String? = when {
        name.isEmpty() -> "Name cannot be empty"
        types.value.any { it.id != excludeId && it.name.equals(name, ignoreCase = true) } ->
            "A type named \"$name\" already exists"
        else -> null
    }

    companion object {
        /** "12.5" or "12,50" -> 1250. Returns null when not a valid number. */
        fun parseToCents(text: String): Long? = runCatching {
            text.trim().replace(',', '.').toBigDecimal()
                .movePointRight(2)
                .setScale(0, RoundingMode.HALF_UP)
                .longValueExact()
        }.getOrNull()

        fun formatCents(cents: Long): String = "%d.%02d".format(cents / 100, cents % 100)
    }
}
