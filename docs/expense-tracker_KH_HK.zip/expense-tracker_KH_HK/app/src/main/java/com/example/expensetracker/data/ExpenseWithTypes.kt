package com.example.expensetracker.data

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation

/** An expense together with the types it is tagged with. */
data class ExpenseWithTypes(
    @Embedded val expense: Expense,
    @Relation(
        parentColumn = "id",
        entityColumn = "id",
        associateBy = Junction(
            value = ExpenseTypeCrossRef::class,
            parentColumn = "expenseId",
            entityColumn = "typeId"
        )
    )
    val types: List<ExpenseType>
)
