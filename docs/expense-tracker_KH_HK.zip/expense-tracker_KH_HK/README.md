# Expense Tracker (Android)

Track expenses with an amount, optional note, and one or more **types** (tags such as "Food" or "Travel").
Types are managed in a separate view (Types → add / rename / delete). Running total is shown on the main screen.

**Stack:** Kotlin · Jetpack Compose (Material 3) · Room (schema v2) · ViewModel + Flow · Gradle (Kotlin DSL)

## Structure

```
app/src/main/java/com/example/expensetracker/
├── MainActivity.kt        # Compose UI: expenses screen, add dialog, types screen
├── ExpenseViewModel.kt    # State + validation + add/delete logic, amount parsing
└── data/
    ├── Expense.kt             # Expense entity (amount in cents)
    ├── ExpenseType.kt         # Type entity (unique name)
    ├── ExpenseTypeCrossRef.kt # Many-to-many link expense <-> type
    ├── ExpenseWithTypes.kt    # Relation: expense + its types
    ├── ExpenseDao.kt
    ├── ExpenseTypeDao.kt
    └── AppDatabase.kt
```

## Build & run

1. Open the `expense-tracker-android` folder in Android Studio (Ladybug / 2024.2 or newer).
2. Let Gradle sync. Android Studio will generate the Gradle wrapper jar if missing;
   otherwise run `gradle wrapper --gradle-version 8.9` once from a machine with Gradle installed.
3. Run on a device/emulator with API 24+.

Requirements: JDK 17, Android SDK 35.

## Notes

- Upgrading from v1 (the first build) drops existing expenses: the database uses `fallbackToDestructiveMigration()` and no migration is provided.
- Deleting a type removes it from all expenses (the expenses themselves are kept).
- The Room schema has not been compiled or run.
