# Expense Tracker ProGuard Rules
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keepclassmembers,allowshrinking class * {
    @dagger.hilt.android.components.* <init>();
}
-keep class androidx.room.** { *; }
-keep class com.example.expensetracker.data.local.** { *; }
