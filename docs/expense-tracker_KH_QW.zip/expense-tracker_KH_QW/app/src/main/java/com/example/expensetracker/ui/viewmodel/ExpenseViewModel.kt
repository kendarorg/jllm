package com.example.expensetracker.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.expensetracker.data.local.Category
import com.example.expensetracker.data.local.Expense
import com.example.expensetracker.data.local.ExpenseWithCategories
import com.example.expensetracker.data.repository.ExpenseRepository
import com.example.expensetracker.domain.usecase.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface ExpenseUiState {
    object Loading : ExpenseUiState
    data class Success(
        val expenses: List<ExpenseWithCategories>,
        val total: Double,
        val periodLabel: String
    ) : ExpenseUiState
    data class Error(val message: String) : ExpenseUiState
}

sealed interface CategoryUiState {
    object Loading : CategoryUiState
    data class Success(val categories: List<Category>) : CategoryUiState
    data class Error(val message: String) : CategoryUiState
}

@HiltViewModel
class ExpenseViewModel @Inject constructor(
    private val getAllExpensesWithCategories: GetAllExpensesWithCategories,
    private val addExpense: AddExpense,
    private val deleteExpense: DeleteExpense,
    private val updateExpense: UpdateExpense,
    private val getTotalAmount: GetTotalAmount,
    private val getAllCategories: GetAllCategories,
    private val addCategory: AddCategory,
    private val deleteCategory: DeleteCategory,
    private val addExpenseWithCategories: AddExpenseWithCategories,
    private val repository: ExpenseRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ExpenseUiState>(ExpenseUiState.Loading)
    val uiState: StateFlow<ExpenseUiState> = _uiState.asStateFlow()

    private val _categoryUiState = MutableStateFlow<CategoryUiState>(CategoryUiState.Loading)
    val categoryUiState: StateFlow<CategoryUiState> = _categoryUiState.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage

    private var currentFilter: DateFilter = DateFilter.THIS_MONTH

    fun setFilter(filter: DateFilter) {
        currentFilter = filter
        loadExpenses()
    }

    fun loadExpenses() {
        viewModelScope.launch {
            _uiState.value = ExpenseUiState.Loading
            try {
                val (start, end, label) = currentFilter.getRange()
                val expensesWithCategories = getAllExpensesWithCategories.execute()
                val total = getTotalAmount.execute(start, end)
                _uiState.value = ExpenseUiState.Success(
                    expenses = expensesWithCategories,
                    total = total,
                    periodLabel = label
                )
            } catch (e: Exception) {
                _uiState.value = ExpenseUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun addExpense(amount: Double, description: String, categoryIds: List<Long>, date: Long) {
        viewModelScope.launch {
            val expense = Expense(
                amount = amount,
                description = description,
                date = date
            )
            addExpenseWithCategories.execute(expense, categoryIds)
            loadExpenses()
            _snackbarMessage.value = "Expense added successfully"
        }
    }

    fun updateExpense(expense: Expense) {
        viewModelScope.launch {
            updateExpense.execute(expense)
            loadExpenses()
            _snackbarMessage.value = "Expense updated successfully"
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            deleteExpense.execute(expense)
            loadExpenses()
            _snackbarMessage.value = "Expense deleted"
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    // --- Category management ---

    fun loadCategories() {
        viewModelScope.launch {
            _categoryUiState.value = CategoryUiState.Loading
            try {
                val categories = getAllCategories.execute()
                _categoryUiState.value = CategoryUiState.Success(categories)
            } catch (e: Exception) {
                _categoryUiState.value = CategoryUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun addCategory(name: String, color: Long = 0xFF6366F1L) {
        viewModelScope.launch {
            val category = Category(name = name, color = color)
            addCategory.execute(category)
            loadCategories()
            _snackbarMessage.value = "Category added: $name"
        }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            deleteCategory.execute(category)
            loadCategories()
            _snackbarMessage.value = "Category deleted: ${category.name}"
        }
    }

    fun updateCategory(category: Category) {
        viewModelScope.launch {
            repository.updateCategory(category)
            loadCategories()
            _snackbarMessage.value = "Category updated: ${category.name}"
        }
    }

    fun setCategoryActive(id: Long, active: Boolean) {
        viewModelScope.launch {
            repository.setCategoryActive(id, active)
            loadCategories()
        }
    }
}
