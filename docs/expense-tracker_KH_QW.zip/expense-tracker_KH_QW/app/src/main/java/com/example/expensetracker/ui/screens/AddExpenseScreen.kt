package com.example.expensetracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.expensetracker.R
import com.example.expensetracker.data.local.Category
import com.example.expensetracker.data.local.Expense
import com.example.expensetracker.ui.viewmodel.ExpenseViewModel
import com.example.expensetracker.ui.viewmodel.CategoryUiState
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddExpenseScreen(
    onNavigateBack: () -> Unit,
    viewModel: ExpenseViewModel = hiltViewModel()
) {
    var amount by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedDate by remember { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var showCategoryPicker by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var editingExpense: Expense? by remember { mutableStateOf(null) }
    var selectedCategoryIds by remember { mutableStateOf<List<Long>>(emptyList()) }

    val categoryUiState by viewModel.categoryUiState.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.loadCategories()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add Expense") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                actions = {
                    editingExpense?.let {
                        IconButton(onClick = { showDeleteDialog = true }) {
                            Icon(Icons.Default.Delete, "Delete")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Amount field
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it },
                label = { Text("Amount") },
                placeholder = { Text("0.00") },
                keyboardOptions = androidx.compose.ui.text.input.KeyboardOptions(
                    keyboardType = KeyboardType.Decimal
                ),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // Description field
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                placeholder = { Text("What did you spend on?") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // Category selector (opens multi-select)
            OutlinedButton(
                onClick = { showCategoryPicker = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (selectedCategoryIds.isEmpty()) "Select Categories" else
                        "Selected: ${selectedCategoryIds.size} category(s)"
                )
            }

            // Show selected categories as chips
            if (selectedCategoryIds.isNotEmpty()) {
                FlowRow(
                    mainAxisSpacing = 8.dp,
                    crossAxisSpacing = 8.dp
                ) {
                    // We'll show categories from the loaded list
                    when (val state = categoryUiState) {
                        is CategoryUiState.Success -> {
                            state.categories
                                .filter { it.id in selectedCategoryIds }
                                .forEach { category ->
                                    AssistChip(
                                        onClick = {
                                            selectedCategoryIds = selectedCategoryIds - category.id
                                        },
                                        label = { Text(category.name) },
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Remove",
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    )
                                }
                        }
                        else -> {}
                    }
                }
            }

            // Date selector
            OutlinedButton(
                onClick = { showDatePicker = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Date: ${java.text.SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(selectedDate))}"
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Save button
            Button(
                onClick = {
                    if (amount.isNotEmpty()) {
                        val amountValue = amount.toDoubleOrNull() ?: 0.0
                        if (editingExpense != null) {
                            viewModel.updateExpense(
                                editingExpense!!.copy(
                                    amount = amountValue,
                                    description = description,
                                    date = selectedDate
                                )
                            )
                        } else {
                            viewModel.addExpense(amountValue, description, selectedCategoryIds, selectedDate)
                        }
                        onNavigateBack()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                enabled = amount.isNotEmpty()
            ) {
                Text("Save Expense")
            }
        }
    }

    // Multi-select category dialog
    if (showCategoryPicker) {
        AlertDialog(
            onDismissRequest = { showCategoryPicker = false },
            title = { Text("Select Categories") },
            text = {
                when (val state = categoryUiState) {
                    is CategoryUiState.Loading -> {
                        CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
                    }
                    is CategoryUiState.Success -> {
                        Column {
                            if (state.categories.isEmpty()) {
                                Text(
                                    text = "No categories available. Go to Settings to add categories first.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                state.categories.forEach { category ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = selectedCategoryIds.contains(category.id),
                                            onCheckedChange = { checked ->
                                                selectedCategoryIds = if (checked) {
                                                    selectedCategoryIds + category.id
                                                } else {
                                                    selectedCategoryIds - category.id
                                                }
                                            }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = category.name)
                                    }
                                }
                            }
                        }
                    }
                    is CategoryUiState.Error -> {
                        Text(
                            text = state.message,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCategoryPicker = false }) {
                    Text("Done")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCategoryPicker = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Date picker dialog
    if (showDatePicker) {
        AlertDialog(
            onDismissRequest = { showDatePicker = false },
            title = { Text("Select Date") },
            text = {
                val calendar = Calendar.getInstance()
                calendar.timeInMillis = selectedDate
                var year by remember { mutableStateOf(calendar.get(Calendar.YEAR)) }
                var month by remember { mutableStateOf(calendar.get(Calendar.MONTH)) }
                var day by remember { mutableStateOf(calendar.get(Calendar.DAY_OF_MONTH)) }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    NumberPicker(
                        value = year,
                        onValueChange = { year = it },
                        range = 2020..2030
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    NumberPicker(
                        value = month,
                        onValueChange = { month = it },
                        range = 0..11
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    NumberPicker(
                        value = day,
                        onValueChange = { day = it },
                        range = 1..31
                    )
                }

                LaunchedEffect(year, month, day) {
                    selectedDate = Calendar
                        .getInstance()
                        .apply {
                            set(year, month, day)
                        }
                        .timeInMillis
                }
            },
            confirmButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete confirmation dialog
    if (showDeleteDialog && editingExpense != null) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Expense") },
            text = { Text("Are you sure you want to delete this expense?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        editingExpense?.let { viewModel.deleteExpense(it) }
                        showDeleteDialog = false
                        onNavigateBack()
                    }
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun NumberPicker(
    value: Int,
    onValueChange: (Int) -> Unit,
    range: IntRange
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        TextButton(onClick = { onValueChange(value - 1) }) {
            Text("▲")
        }
        Text(
            text = value.toString(),
            style = MaterialTheme.typography.headlineMedium
        )
        TextButton(onClick = { onValueChange(value + 1) }) {
            Text("▼")
        }
    }
}

@Composable
private fun FlowRow(
    mainAxisSpacing: Dp,
    crossAxisSpacing: Dp,
    content: @Composable () -> Unit
) {
    // Simple flow row implementation using Column and Row
    Column {
        Row(
            horizontalArrangement = Arrangement.spacedBy(mainAxisSpacing),
            verticalAlignment = Alignment.Top,
            modifier = Modifier.fillMaxWidth()
        ) {
            content()
        }
    }
}
