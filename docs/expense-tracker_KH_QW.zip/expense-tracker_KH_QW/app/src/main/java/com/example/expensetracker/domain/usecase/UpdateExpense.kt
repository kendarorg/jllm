package com.example.expensetracker.domain.usecase

import com.example.expensetracker.data.local.Expense
import com.example.expensetracker.data.repository.ExpenseRepository
import javax.inject.Inject

class UpdateExpense @Inject constructor(
    private val repository: ExpenseRepository
) {
    suspend fun execute(expense: Expense) = repository.updateExpense(expense)
}
