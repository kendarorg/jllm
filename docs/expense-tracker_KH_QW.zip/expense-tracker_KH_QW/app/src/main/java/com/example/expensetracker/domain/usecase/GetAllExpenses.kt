package com.example.expensetracker.domain.usecase

import com.example.expensetracker.data.local.Expense
import com.example.expensetracker.data.repository.ExpenseRepository
import javax.inject.Inject

class GetAllExpenses @Inject constructor(
    private val repository: ExpenseRepository
) {
    suspend fun execute(): List<Expense> = repository.getAllExpenses()
}
