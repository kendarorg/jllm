package com.example.expensetracker.data.repository

import com.example.expensetracker.data.local.*
import javax.inject.Inject

class ExpenseRepository @Inject constructor(
    private val expenseDao: ExpenseDao,
    private val categoryDao: CategoryDao,
    private val expenseCategoryDao: ExpenseCategoryDao
) {

    // --- Expense operations ---
    suspend fun getAllExpensesWithCategories(): List<ExpenseWithCategories> =
        expenseDao.getAllExpensesWithCategories()

    suspend fun getAllExpenses(): List<Expense> = expenseDao.getAllExpenses()
    suspend fun getExpenseById(id: Long): Expense? = expenseDao.getExpenseById(id)
    suspend fun insertExpense(expense: Expense): Long = expenseDao.insertExpense(expense)
    suspend fun updateExpense(expense: Expense) = expenseDao.updateExpense(expense)
    suspend fun deleteExpense(expense: Expense) = expenseDao.deleteExpense(expense)
    suspend fun deleteAllExpenses() = expenseDao.deleteAllExpenses()
    suspend fun getTotalAmountInRange(startMillis: Long, endMillis: Long): Double =
        expenseDao.getTotalAmountInRange(startMillis, endMillis) ?: 0.0

    // --- Category operations ---
    suspend fun getAllCategories(): List<Category> = categoryDao.getAllCategories()
    suspend fun getCategoryById(id: Long): Category? = categoryDao.getCategoryById(id)
    suspend fun getActiveCategories(): List<Category> = categoryDao.getActiveCategories()
    suspend fun insertCategory(category: Category): Long = categoryDao.insertCategory(category)
    suspend fun updateCategory(category: Category) = categoryDao.updateCategory(category)
    suspend fun deleteCategory(category: Category) = categoryDao.deleteCategory(category)
    suspend fun setCategoryActive(id: Long, active: Boolean) = categoryDao.setCategoryActive(id, active)

    // --- Expense-Category relationship operations ---
    suspend fun getCategoriesForExpense(expenseId: Long): List<Category> {
        val relationships = expenseCategoryDao.getCategoriesForExpense(expenseId)
        return relationships.mapNotNull { rel ->
            categoryDao.getCategoryById(rel.categoryId)
        }
    }

    suspend fun addCategoriesToExpense(expenseId: Long, categoryIds: List<Long>) {
        val relationships = categoryIds.map { categoryId ->
            ExpenseCategory(expenseId = expenseId, categoryId = categoryId)
        }
        expenseCategoryDao.insertExpenseCategories(relationships)
    }

    suspend fun removeCategoriesFromExpense(expenseId: Long) =
        expenseCategoryDao.deleteCategoriesForExpense(expenseId)

    suspend fun removeCategoryFromAllExpenses(categoryId: Long) =
        expenseCategoryDao.deleteCategoryForAllExpenses(categoryId)
}
