package com.example.expensetracker.domain.usecase

import com.example.expensetracker.data.local.Category
import com.example.expensetracker.data.repository.ExpenseRepository
import javax.inject.Inject

class GetAllCategories @Inject constructor(
    private val repository: ExpenseRepository
) {
    suspend fun execute(): List<Category> = repository.getAllCategories()

    suspend fun executeActive(): List<Category> = repository.getActiveCategories()
}
