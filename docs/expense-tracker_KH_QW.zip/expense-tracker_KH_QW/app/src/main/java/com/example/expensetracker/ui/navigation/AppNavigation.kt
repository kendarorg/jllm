package com.example.expensetracker.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.expensetracker.ui.screens.AddExpenseScreen
import com.example.expensetracker.ui.screens.CategoryManagementScreen
import com.example.expensetracker.ui.screens.HomeScreen
import com.example.expensetracker.ui.screens.SettingsScreen

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object AddExpense : Screen("add_expense")
    object Settings : Screen("settings")
    object ManageCategories : Screen("manage_categories")
}

@Composable
fun AppNavigation() {
    val navController = androidx.navigation.compose.rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                onAddExpense = { navController.navigate(Screen.AddExpense.route) },
                onSettingsClick = { navController.navigate(Screen.Settings.route) },
                onManageCategories = { navController.navigate(Screen.ManageCategories.route) }
            )
        }
        composable(Screen.AddExpense.route) {
            AddExpenseScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Settings.route) {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() },
                onManageCategories = { navController.navigate(Screen.ManageCategories.route) }
            )
        }
        composable(Screen.ManageCategories.route) {
            CategoryManagementScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
