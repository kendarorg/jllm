package com.example.expensetracker.domain.usecase

import com.example.expensetracker.data.local.Category
import com.example.expensetracker.data.local.Expense
import com.example.expensetracker.data.local.ExpenseCategory
import com.example.expensetracker.data.repository.ExpenseRepository
import javax.inject.Inject

class AddExpenseWithCategories @Inject constructor(
    private val repository: ExpenseRepository
) {
    suspend fun execute(expense: Expense, categoryIds: List<Long>): Long {
        val expenseId = repository.insertExpense(expense)
        if (categoryIds.isNotEmpty()) {
            repository.addCategoriesToExpense(expenseId, categoryIds)
        }
        return expenseId
    }
}
