package com.example.expensetracker.data.local

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation

data class ExpenseWithCategories(
    @Embedded val expense: Expense,
    @Relation(
        entity = Category::class,
        parentColumn = "id",
        entityColumn = "id",
        associateBy = Junction(ExpenseCategory::class)
    )
    val categories: List<Category>
)
