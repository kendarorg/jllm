package com.example.expensetracker.domain.usecase

import com.example.expensetracker.data.local.ExpenseWithCategories
import com.example.expensetracker.data.repository.ExpenseRepository
import javax.inject.Inject

class GetAllExpensesWithCategories @Inject constructor(
    private val repository: ExpenseRepository
) {
    suspend fun execute(): List<ExpenseWithCategories> =
        repository.getAllExpensesWithCategories()
}
