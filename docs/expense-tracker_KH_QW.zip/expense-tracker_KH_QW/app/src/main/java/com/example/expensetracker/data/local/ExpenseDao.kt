package com.example.expensetracker.data.local

import androidx.room.*

@Dao
interface ExpenseDao {

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    suspend fun getAllExpenses(): List<Expense>

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    suspend fun getAllExpensesWithCategories(): List<ExpenseWithCategories>

    @Query("SELECT * FROM expenses WHERE id = :id")
    suspend fun getExpenseById(id: Long): Expense?

    @Query("SELECT * FROM expenses WHERE id = :id")
    suspend fun getExpenseWithCategoriesById(id: Long): ExpenseWithCategories?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: Expense): Long

    @Update
    suspend fun updateExpense(expense: Expense)

    @Delete
    suspend fun deleteExpense(expense: Expense)

    @Query("DELETE FROM expenses")
    suspend fun deleteAllExpenses()

    @Query("SELECT SUM(amount) FROM expenses WHERE date BETWEEN :startMillis AND :endMillis")
    suspend fun getTotalAmountInRange(startMillis: Long, endMillis: Long): Double?
}
