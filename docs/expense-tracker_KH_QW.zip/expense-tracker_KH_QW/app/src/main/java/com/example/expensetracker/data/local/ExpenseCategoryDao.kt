package com.example.expensetracker.data.local

import androidx.room.*

@Dao
interface ExpenseCategoryDao {

    @Query("SELECT * FROM expense_categories WHERE expenseId = :expenseId")
    suspend fun getCategoriesForExpense(expenseId: Long): List<Category>

    @Query("SELECT * FROM expense_categories WHERE categoryId = :categoryId")
    suspend fun getExpensesForCategory(categoryId: Long): List<Expense>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpenseCategory(relationship: ExpenseCategory): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpenseCategories(relationships: List<ExpenseCategory>)

    @Delete
    suspend fun deleteExpenseCategory(relationship: ExpenseCategory)

    @Query("DELETE FROM expense_categories WHERE expenseId = :expenseId")
    suspend fun deleteCategoriesForExpense(expenseId: Long)

    @Query("DELETE FROM expense_categories WHERE categoryId = :categoryId")
    suspend fun deleteCategoryForAllExpenses(categoryId: Long)
}
