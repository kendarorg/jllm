package com.example.expensetracker.domain.usecase

import com.example.expensetracker.data.local.Category
import com.example.expensetracker.data.repository.ExpenseRepository
import javax.inject.Inject

class AddCategory @Inject constructor(
    private val repository: ExpenseRepository
) {
    suspend fun execute(category: Category): Long = repository.insertCategory(category)
}
