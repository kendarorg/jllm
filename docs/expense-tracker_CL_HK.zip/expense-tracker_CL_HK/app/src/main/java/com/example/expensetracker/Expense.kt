package com.example.expensetracker

data class ExpenseType(
    val id: Long,
    val name: String
)

data class Expense(
    val id: Long,
    val amount: Double,
    val typeIds: List<Long>,
    val description: String,
    val date: Long
)
