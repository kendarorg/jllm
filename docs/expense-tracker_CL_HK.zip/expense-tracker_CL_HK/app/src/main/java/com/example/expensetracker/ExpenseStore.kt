package com.example.expensetracker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ExpenseStore(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    init {
        if (!prefs.contains(KEY_TYPES)) {
            saveTypes(DEFAULT_TYPES.mapIndexed { index, name -> ExpenseType(index + 1L, name) })
        }
    }

    fun getTypes(): List<ExpenseType> {
        val raw = prefs.getString(KEY_TYPES, null) ?: return emptyList()
        val array = JSONArray(raw)
        return (0 until array.length())
            .map { array.getJSONObject(it) }
            .map { ExpenseType(id = it.getLong("id"), name = it.getString("name")) }
            .sortedBy { it.name.lowercase() }
    }

    fun addType(name: String) {
        val types = getTypes()
        val nextId = (types.maxOfOrNull { it.id } ?: 0L) + 1
        saveTypes(types + ExpenseType(nextId, name))
    }

    fun renameType(id: Long, name: String) {
        saveTypes(getTypes().map { if (it.id == id) it.copy(name = name) else it })
    }

    fun deleteType(id: Long) {
        saveTypes(getTypes().filter { it.id != id })
        saveExpenses(getAll().map { it.copy(typeIds = it.typeIds - id) })
    }

    fun getAll(): List<Expense> {
        val raw = prefs.getString(KEY_EXPENSES, null) ?: return emptyList()
        val array = JSONArray(raw)
        return (0 until array.length())
            .map { array.getJSONObject(it) }
            .map { o ->
                val typeArray = o.optJSONArray("typeIds") ?: JSONArray()
                Expense(
                    id = o.getLong("id"),
                    amount = o.getDouble("amount"),
                    typeIds = (0 until typeArray.length()).map { typeArray.getLong(it) },
                    description = o.getString("description"),
                    date = o.getLong("date")
                )
            }
            .sortedByDescending { it.date }
    }

    fun addExpense(amount: Double, typeIds: List<Long>, description: String) {
        val now = System.currentTimeMillis()
        val expense = Expense(
            id = now,
            amount = amount,
            typeIds = typeIds,
            description = description,
            date = now
        )
        saveExpenses(getAll() + expense)
    }

    fun deleteExpense(id: Long) {
        saveExpenses(getAll().filter { it.id != id })
    }

    private fun saveTypes(types: List<ExpenseType>) {
        val array = JSONArray()
        types.forEach { t ->
            array.put(JSONObject().put("id", t.id).put("name", t.name))
        }
        prefs.edit().putString(KEY_TYPES, array.toString()).apply()
    }

    private fun saveExpenses(expenses: List<Expense>) {
        val array = JSONArray()
        expenses.forEach { e ->
            val typeArray = JSONArray()
            e.typeIds.forEach { typeArray.put(it) }
            array.put(
                JSONObject()
                    .put("id", e.id)
                    .put("amount", e.amount)
                    .put("typeIds", typeArray)
                    .put("description", e.description)
                    .put("date", e.date)
            )
        }
        prefs.edit().putString(KEY_EXPENSES, array.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "expense_tracker"
        private const val KEY_EXPENSES = "expenses"
        private const val KEY_TYPES = "types"
        private val DEFAULT_TYPES = listOf("Food", "Transport", "Housing", "Utilities", "Entertainment", "Health", "Other")
    }
}
