package com.example.expensetracker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.text.NumberFormat
import java.util.Date

class MainActivity : Activity() {

    private lateinit var store: ExpenseStore
    private lateinit var amountInput: EditText
    private lateinit var descriptionInput: EditText
    private lateinit var typesButton: Button
    private lateinit var totalText: TextView
    private lateinit var listView: ListView
    private lateinit var listAdapter: ArrayAdapter<String>

    private var types: List<ExpenseType> = emptyList()
    private val selectedTypeIds = mutableSetOf<Long>()
    private var expenses: List<Expense> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = ExpenseStore(this)
        amountInput = findViewById(R.id.amountInput)
        descriptionInput = findViewById(R.id.descriptionInput)
        typesButton = findViewById(R.id.typesButton)
        totalText = findViewById(R.id.totalText)
        listView = findViewById(R.id.listView)

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1)
        listView.adapter = listAdapter

        typesButton.setOnClickListener { showTypePicker() }
        findViewById<Button>(R.id.manageTypesButton).setOnClickListener {
            startActivity(Intent(this, ManageTypesActivity::class.java))
        }
        findViewById<Button>(R.id.addButton).setOnClickListener { onAddClicked() }

        listView.setOnItemLongClickListener { _, _, position, _ ->
            confirmDelete(expenses[position])
            true
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun onAddClicked() {
        val amount = amountInput.text.toString().toDoubleOrNull()
        if (amount == null || amount <= 0.0) {
            toast(R.string.toast_invalid_amount)
            return
        }
        if (selectedTypeIds.isEmpty()) {
            toast(R.string.toast_no_type_selected)
            return
        }
        store.addExpense(amount, selectedTypeIds.toList(), descriptionInput.text.toString().trim())
        amountInput.text.clear()
        descriptionInput.text.clear()
        selectedTypeIds.clear()
        refresh()
    }

    private fun showTypePicker() {
        if (types.isEmpty()) {
            toast(R.string.toast_no_types)
            return
        }
        val names = types.map { it.name }.toTypedArray()
        val checked = types.map { it.id in selectedTypeIds }.toBooleanArray()
        val pending = selectedTypeIds.toMutableSet()
        AlertDialog.Builder(this)
            .setTitle(R.string.title_select_types)
            .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                val id = types[which].id
                if (isChecked) pending.add(id) else pending.remove(id)
            }
            .setPositiveButton(R.string.button_done) { _, _ ->
                selectedTypeIds.clear()
                selectedTypeIds.addAll(pending)
                updateTypesButton()
            }
            .setNegativeButton(R.string.button_cancel, null)
            .show()
    }

    private fun confirmDelete(expense: Expense) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setMessage(describe(expense))
            .setPositiveButton(R.string.button_delete) { _, _ ->
                store.deleteExpense(expense.id)
                refresh()
            }
            .setNegativeButton(R.string.button_cancel, null)
            .show()
    }

    private fun refresh() {
        types = store.getTypes()
        selectedTypeIds.retainAll(types.map { it.id }.toSet())
        expenses = store.getAll()
        listAdapter.clear()
        listAdapter.addAll(expenses.map { describe(it) })
        val total = expenses.sumOf { it.amount }
        totalText.text = getString(R.string.total_format, formatMoney(total))
        updateTypesButton()
    }

    private fun updateTypesButton() {
        typesButton.text = typeNames(selectedTypeIds).ifEmpty { getString(R.string.no_types_selected) }
    }

    private fun describe(expense: Expense): String {
        val date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(expense.date))
        val description = if (expense.description.isEmpty()) "" else " - ${expense.description}"
        return "$date  ${typeNames(expense.typeIds)}  ${formatMoney(expense.amount)}$description"
    }

    private fun typeNames(ids: Collection<Long>): String =
        types.filter { it.id in ids }.joinToString { it.name }

    private fun formatMoney(value: Double): String =
        NumberFormat.getCurrencyInstance().format(value)

    private fun toast(messageRes: Int) {
        Toast.makeText(this, messageRes, Toast.LENGTH_SHORT).show()
    }
}
