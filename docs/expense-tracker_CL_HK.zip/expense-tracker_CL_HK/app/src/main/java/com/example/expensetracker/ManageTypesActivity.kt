package com.example.expensetracker

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast

class ManageTypesActivity : Activity() {

    private lateinit var store: ExpenseStore
    private lateinit var nameInput: EditText
    private lateinit var listView: ListView
    private lateinit var listAdapter: ArrayAdapter<String>

    private var types: List<ExpenseType> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_types)

        store = ExpenseStore(this)
        nameInput = findViewById(R.id.nameInput)
        listView = findViewById(R.id.typeList)

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1)
        listView.adapter = listAdapter

        findViewById<Button>(R.id.addTypeButton).setOnClickListener { onAddClicked() }

        listView.setOnItemClickListener { _, _, position, _ ->
            showRenameDialog(types[position])
        }
        listView.setOnItemLongClickListener { _, _, position, _ ->
            confirmDelete(types[position])
            true
        }

        refresh()
    }

    private fun onAddClicked() {
        val name = nameInput.text.toString().trim()
        if (!isValidName(name, exceptId = null)) return
        store.addType(name)
        nameInput.text.clear()
        refresh()
    }

    private fun showRenameDialog(type: ExpenseType) {
        val input = EditText(this).apply { setText(type.name) }
        AlertDialog.Builder(this)
            .setTitle(R.string.rename_title)
            .setView(input)
            .setPositiveButton(R.string.button_save) { _, _ ->
                val name = input.text.toString().trim()
                if (isValidName(name, exceptId = type.id)) {
                    store.renameType(type.id, name)
                    refresh()
                }
            }
            .setNegativeButton(R.string.button_cancel, null)
            .show()
    }

    private fun confirmDelete(type: ExpenseType) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_type_title)
            .setMessage(getString(R.string.delete_type_message, type.name))
            .setPositiveButton(R.string.button_delete) { _, _ ->
                store.deleteType(type.id)
                refresh()
            }
            .setNegativeButton(R.string.button_cancel, null)
            .show()
    }

    private fun isValidName(name: String, exceptId: Long?): Boolean {
        if (name.isEmpty()) {
            toast(R.string.toast_type_empty)
            return false
        }
        val duplicate = types.any { it.name.equals(name, ignoreCase = true) && it.id != exceptId }
        if (duplicate) {
            toast(R.string.toast_type_duplicate)
            return false
        }
        return true
    }

    private fun refresh() {
        types = store.getTypes()
        listAdapter.clear()
        listAdapter.addAll(types.map { it.name })
    }

    private fun toast(messageRes: Int) {
        Toast.makeText(this, messageRes, Toast.LENGTH_SHORT).show()
    }
}
