# Expense Tracker

Minimal Android expense tracker (Kotlin, classic Views, no third-party dependencies).

- Manage types (e.g. Food, Transport) from the "Manage types" screen: add, rename (tap), delete (long-press).
- Add an expense: amount, one or more types, optional description.
- List of expenses, newest first, with running total.
- Long-press an expense to delete it.
- Data is stored locally in SharedPreferences as JSON. Default types are seeded on first run.

## Open / build

Source only; the Gradle wrapper is not included. Either:

- Open the `expense-tracker` folder in Android Studio (it generates the wrapper), or
- Run `gradle wrapper --gradle-version 8.9` once with a local Gradle install, then `./gradlew assembleDebug`.

Requirements: JDK 17, Android SDK platform 35, minSdk 24.
